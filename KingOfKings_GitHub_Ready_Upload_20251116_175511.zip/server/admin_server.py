from flask import Flask, request, jsonify, send_from_directory
import os, json, time, jwt
app = Flask('king_admin')
cfg_path = os.path.join('config','settings.json')
CFG = {}
if os.path.exists(cfg_path): CFG = json.load(open(cfg_path))
JWT_SECRET = CFG.get('jwt_secret','change_me')

@app.route('/api/status')
def status():
    return jsonify({'ok':True,'version':CFG.get('version','1.0'),'theme':CFG.get('theme','king_modern')})

@app.route('/token', methods=['POST'])
def token():
    data = request.json or {}
    if data.get('admin_key')=='supersecret':
        payload={'admin':True,'iat':int(time.time())}
        t = jwt.encode(payload, JWT_SECRET, algorithm='HS256')
        return jsonify({'token':t})
    return jsonify({'error':'invalid'}),401

@app.route('/api/queue', methods=['GET','POST'])
def queue_api():
    qfile = os.path.join('data','queue.json')
    if request.method=='GET':
        if os.path.exists(qfile): return jsonify(json.load(open(qfile)))
        return jsonify([])
    data = request.json or {}
    path = data.get('path') or data.get('song')
    if not path: return jsonify({'error':'no path'}),400
    os.makedirs('data', exist_ok=True)
    q = json.load(open(qfile)) if os.path.exists(qfile) else []
    q.append(path); json.dump(q, open(qfile,'w'), indent=2)
    return jsonify({'ok':True,'queue':q})

if __name__=='__main__':
    app.run(host='0.0.0.0', port=5000)
