import os, random
class RecommendationEngine:
    def more_like_this(self, path, count=8):
        base='media/songs'
        allf=[]
        for root,_,files in os.walk(base):
            for f in files:
                if f.lower().endswith(('.mp3','.wav')): allf.append(os.path.join(root,f))
        if path in allf: allf.remove(path)
        random.shuffle(allf)
        return allf[:count]
