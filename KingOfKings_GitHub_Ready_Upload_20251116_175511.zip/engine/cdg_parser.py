def parse_cdg(p): return [(0,'Line1'),(3,'Line2')]
