import os, json
class PlaylistManager:
    def __init__(self, player):
        self.player = player
        self.queue = []
        os.makedirs('data', exist_ok=True)
        self.file='data/playlist.json'

    def add(self, path):
        if os.path.exists(path):
            self.queue.append(path); self._save()

    def pop_next(self):
        if self.queue:
            p=self.queue.pop(0); self._save(); return p
        return None

    def _save(self):
        with open(self.file,'w') as f: json.dump(self.queue,f)
