# crossfader stub
class CrossFader:
    def __init__(self, player): self.player=player
    def crossfade_to(self,p): self.player.play(p)
