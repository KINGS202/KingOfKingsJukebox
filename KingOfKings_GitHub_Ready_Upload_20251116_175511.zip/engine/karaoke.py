class KaraokeEngine:
    def __init__(self): pass
    def load(self,audio,cdg=None): self.audio=audio; self.cdg=cdg
    def start(self): print('Karaoke start (stub)')
    def stop(self): print('Karaoke stop')
