import os
def smart_search(q, media_dir='media/songs'):
    res=[]
    q=q.lower()
    for root,_,files in os.walk(media_dir):
        for f in files:
            if q in f.lower():
                res.append(os.path.join(root,f))
    return res

class SearchEngine:
    def search(self, q): return smart_search(q)
